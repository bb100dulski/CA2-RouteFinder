package Tests;

import Classes.GraphNodeAL;
import Classes.GraphNodeAL2;
import Classes.Placemark;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import java.util.ArrayList;
import java.util.List;

import static Classes.GraphNodeAL.findPathBreadthFirst;
import static Classes.GraphNodeAL.findPathDepthFirst;
import static Classes.GraphNodeAL2.findCheapestPathDijkstra;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class mainTest {


    ArrayList<Placemark> testArrayList = new ArrayList<>();

    Placemark placemark1 = new Placemark("Landmark", "Colosseum", "null", "0", "0");
    Placemark placemark2 = new Placemark("Landmark", "Pantheon", "null", "0", "0");
    Placemark placemark3 = new Placemark("Landmark", "Leonardo da Vinci International Airport", "null", "0", "0");

    GraphNodeAL<String> Colosseum = new GraphNodeAL<>(placemark1.getName());
    GraphNodeAL<String> Pantheon = new GraphNodeAL<>(placemark2.getName());
    GraphNodeAL<String> LeonardoDaVinci = new GraphNodeAL<>(placemark3.getName());

    GraphNodeAL2<String> ColosseumDjikstra = new GraphNodeAL2<>(placemark1.getName());
    GraphNodeAL2<String> PantheonDjikstra = new GraphNodeAL2<>(placemark2.getName());
    GraphNodeAL2<String> LeonardoDaVinciDjikstra = new GraphNodeAL2<>(placemark3.getName());

    @BeforeEach
    public void setUp() {
        testArrayList.add(placemark1);
        testArrayList.add(placemark2);
        testArrayList.add(placemark3);

        Colosseum.connectToNodeUndirected(Pantheon);
        Pantheon.connectToNodeDirected(Colosseum);

        ColosseumDjikstra.connectToNodeDirected(PantheonDjikstra, 14);
        PantheonDjikstra.connectToNodeUndirected(ColosseumDjikstra, 14);
    }

    @AfterEach
    public void tearDown() {
        placemark1 = placemark2 = placemark3 = null;
    }

    @Test
    public void placemarkTest() {
        assertEquals("Colosseum", placemark1.getName());
        assertEquals("Pantheon", placemark2.getName());
        assertEquals("Leonardo da Vinci International Airport", placemark3.getName());
    }

    @Test
    public void arrayListTest() {
        testArrayList.add(placemark1);
        testArrayList.add(placemark2);
        testArrayList.add(placemark3);

        assertEquals("Colosseum", testArrayList.get(0).getName());
        assertEquals("Pantheon", testArrayList.get(1).getName());
        assertEquals("Leonardo da Vinci International Airport", testArrayList.get(2).getName());

        assertEquals(3, testArrayList.size());
    }

    @Test
    public void DFSTest() {
        Colosseum.connectToNodeUndirected(Pantheon);

        List<GraphNodeAL<?>> pathTest = findPathDepthFirst(Colosseum, null, Pantheon);
        if (pathTest != null) {
            for (GraphNodeAL<?> n : pathTest) {
                String output = "\r\n" + (String) n.data;
                System.out.println(output);
            }
        }
        assertEquals("Colosseum", pathTest);
    }

    @Test
    public void BFSTest() {
        List<GraphNodeAL<?>> pathTest = findPathBreadthFirst(Colosseum, Pantheon);
        if (pathTest != null) {
            for (GraphNodeAL<?> n : pathTest) {
                String output = "\r\n" + (String) n.data;
                System.out.println(output);
            }
        }
        assertEquals("Colosseum", pathTest);
    }

    @Test
    public void DjikstraTest() {
        GraphNodeAL2.CostedPath costedPathTest = findCheapestPathDijkstra(ColosseumDjikstra, PantheonDjikstra);
        for (GraphNodeAL2<?> n : costedPathTest.pathList) {
            String output = "\r\n" + (String) n.data + "\r\n";
            System.out.println(output);
        }
        assertEquals("Colosseum", costedPathTest);
    }
}
