package Controllers;

import javafx.fxml.Initializable;
import javafx.scene.layout.Pane;
import javafx.scene.web.WebView;

import java.net.URL;
import java.util.ResourceBundle;

public class webViewController implements Initializable {
    public Pane gMapsPane;
    public WebView gMapsWebView;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //http://tutorials.jenkov.com/javafx/webview.html
        gMapsWebView.getEngine().load("https://goo.gl/maps/vV9bQ4XE1mHemVew7");
    }
}
