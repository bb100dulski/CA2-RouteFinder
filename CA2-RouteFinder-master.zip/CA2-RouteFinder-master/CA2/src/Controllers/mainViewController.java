package Controllers;

import Classes.*;
import com.sun.javafx.geom.Vec2d;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import org.controlsfx.control.textfield.TextFields;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Scalar;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;


import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.awt.Graphics;

import static Classes.GraphNodeAL.findPathBreadthFirst;
import static Classes.GraphNodeAL.findPathDepthFirst;
import static Classes.GraphNodeAL2.findCheapestPathDijkstra;

public class mainViewController implements Initializable {
    public MenuBar menuBar;
    public Menu fileMenuBar;
    public MenuItem quitMenuBar;
    public MenuItem aboutMenuBar;
    public AnchorPane pane;
    public ImageView mapImgView;
    public Button goBtn;
    public TextArea infoTxtBox;
    public Button dataBtn;
    public VBox vBox;
    public TextField originTxtFld;
    public TextField destinationTxtFld;
    public Button gMapsBtn;
    public FlowPane flowPane;
    public TextField nameTxtFld;
    public TextField descTxtFld;
    public TextField xTxtFld;
    public TextField yTxtFld;
    public Button secretBtn;
    public Button exitBtn;
    public ComboBox typeComboBox;
    public ComboBox algoComboBox;
    public ComboBox connectComboBox;
    public ComboBox connectWithCombBox;
    public CheckBox culturalTckBox;
    public CheckBox avoidTckBox;
    public ComboBox avoidCombBox;
    public ScrollPane scrollPane;
    public File file;
    public URL imgURL;
    public ComboBox originComboBox;

    ArrayList<Placemark> placemarksList = new ArrayList<Placemark>();
    Graph graph = new Graph();

    //creates a new graph for each waypoint
    static GraphNodeAL<String> a;
    static GraphNodeAL<String> b;
    static GraphNodeAL<String> c;
    static GraphNodeAL<String> d;
    static GraphNodeAL<String> e;
    static GraphNodeAL<String> f;
    static GraphNodeAL<String> g;
    static GraphNodeAL<String> h;
    static GraphNodeAL<String> i;
    static GraphNodeAL<String> j;

    //Dijsktra
    static GraphNodeAL2<String> Da;
    static GraphNodeAL2<String> Db;
    static GraphNodeAL2<String> Dc;
    static GraphNodeAL2<String> Dd;
    static GraphNodeAL2<String> De;
    static GraphNodeAL2<String> Df;
    static GraphNodeAL2<String> Dg;
    static GraphNodeAL2<String> Dh;
    static GraphNodeAL2<String> Di;
    static GraphNodeAL2<String> Dj;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Rome coords = 41.9028° N, 12.4964° E
        file = new File("rome-map.jpg");
        try {
            imgURL = file.toURI().toURL();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Image image = new Image(imgURL.toExternalForm(),  mapImgView.getFitWidth(), mapImgView.getFitHeight(), false, true);
        mapImgView.setImage(image);

        infoTxtBox.setEditable(false);
        infoTxtBox.setWrapText(true);

        //https://stackoverflow.com/questions/38367107/how-do-i-add-a-value-to-items-in-a-combobox-in-javafx
        typeComboBox.getItems().addAll("Landmark", "Road");

        try {
            readXML();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        for (Placemark placemark : placemarksList) {
            //TextFields.bindAutoCompletion(originTxtFld, placemark.getName());
            TextFields.bindAutoCompletion(destinationTxtFld, placemark.getName());
        }

        //assigns the graphs for each landmark
        a = new GraphNodeAL<String>(placemarksList.get(0).getName()); //Sistine Chapel
        b = new GraphNodeAL<String>(placemarksList.get(1).getName()); //St.Peter's Basilica
        c = new GraphNodeAL<String>(placemarksList.get(2).getName()); //Colosseum
        d = new GraphNodeAL<String>(placemarksList.get(3).getName()); //Pantheon
        e = new GraphNodeAL<String>(placemarksList.get(4).getName()); //Terrazza del Pincio
        f = new GraphNodeAL<String>(placemarksList.get(5).getName()); //Bioparco di Roma
        g = new GraphNodeAL<String>(placemarksList.get(6).getName()); //Roman Forum
        h = new GraphNodeAL<String>(placemarksList.get(7).getName()); //Ponte Sisto
        i = new GraphNodeAL<String>(placemarksList.get(8).getName()); //Roma Termini
        j = new GraphNodeAL<String>(placemarksList.get(9).getName()); //Baths of Caracalla

        //connects the landmarks
        a.connectToNodeUndirected(b); //Sistine  - St.Peter's
        c.connectToNodeUndirected(d); //Colosseum - Pantheon
        e.connectToNodeUndirected(f); //Terrazza - Bioparco
        e.connectToNodeUndirected(a); //Terrazza - Sistine
        f.connectToNodeUndirected(d); //Bioparco - Pantheon
        g.connectToNodeUndirected(d); //Roman Forum - Pantheon
        d.connectToNodeUndirected(i); //Pantheon - Termini
        g.connectToNodeUndirected(i); //Forum - Termini
        h.connectToNodeUndirected(g); //Ponte - Roman Forum
        j.connectToNodeUndirected(c); //Baths - Colosseum
        c.connectToNodeUndirected(g); //Colosseum - Forum

        //Dijsktra
        Da = new GraphNodeAL2<String>(placemarksList.get(0).getName()); //Sistine Chapel
        Db = new GraphNodeAL2<String>(placemarksList.get(1).getName()); //St.Peter's Basilica
        Dc = new GraphNodeAL2<String>(placemarksList.get(2).getName()); //Colosseum
        Dd = new GraphNodeAL2<String>(placemarksList.get(3).getName()); //Pantheon
        De = new GraphNodeAL2<String>(placemarksList.get(4).getName()); //Terrazza del Pincio
        Df = new GraphNodeAL2<String>(placemarksList.get(5).getName()); //Bioparco di Roma
        Dg = new GraphNodeAL2<String>(placemarksList.get(6).getName()); //Roman Forum
        Dh = new GraphNodeAL2<String>(placemarksList.get(7).getName()); //Ponte Sisto
        Di = new GraphNodeAL2<String>(placemarksList.get(8).getName()); //Roma Termini
        Dj = new GraphNodeAL2<String>(placemarksList.get(9).getName()); //Baths of Caracalla

        //connects the landmarks
        Da.connectToNodeUndirected(Db, 6); //Sistine  - St.Peter's
        Dc.connectToNodeUndirected(Dd, 14); //Colosseum - Pantheon
        De.connectToNodeUndirected(Df, 5); //Terrazza - Bioparco
        De.connectToNodeUndirected(Da, 7); //Terrazza - Sistine
        Df.connectToNodeUndirected(Dd, 7); //Bioparco - Pantheon
        Dg.connectToNodeUndirected(Dd, 8); //Roman Forum - Pantheon
        Dd.connectToNodeUndirected(Di, 4); //Pantheon - Termini
        Dg.connectToNodeUndirected(Di, 5); //Forum - Termini
        Dh.connectToNodeUndirected(Dg, 10); //Ponte - Roman Forum
        Dj.connectToNodeUndirected(Dc, 11); //Baths - Colosseum
        Dc.connectToNodeUndirected(Dg, 12); //Colosseum - Forum

        //used for the auto-completion of the textfield
        ArrayList<String> graphData = new ArrayList<>();
        graphData.add(a.data);
        graphData.add(b.data);
        graphData.add(c.data);
        graphData.add(d.data);
        graphData.add(e.data);
        graphData.add(f.data);
        graphData.add(g.data);
        graphData.add(h.data);
        graphData.add(i.data);
        graphData.add(j.data);

        TextFields.bindAutoCompletion(originTxtFld, graphData);

        /*
        originComboBox.getItems().addAll(a.data, b.data, c.data, d.data,
                e.data, f.data, g.data, h.data,
                i.data, j.data);

         */

        avoidCombBox.getItems().addAll(graphData);

        algoComboBox.getItems().addAll("Dijkstra", "BFS");

        //https://stackoverflow.com/questions/1066589/iterate-through-a-hashmap
        for (Graph.Vertex vertex : graph.adjVertices.keySet()) {
            connectComboBox.getItems().addAll(vertex);
            connectWithCombBox.getItems().addAll(vertex);
        }

        setWaypoint();
        setUpMap();

        //graph.adjVertices.clear();

        //playGround();


    }

    //test code here before implementing
    //so far peter's graph works so implement it
    public void playGround() {
        List<GraphNodeAL<?>> path = findPathDepthFirst(i, null, "Baths of Caracalla");
        if (path != null) {
            for (GraphNodeAL<?> n : path) {
                System.out.println(n.data);
            }
        }
    }

    public void saveXML() throws IOException {
        XStream xstream = new XStream(new DomDriver());
        ObjectOutputStream out = xstream.createObjectOutputStream(new FileWriter("placemarks.xml"));
        out.writeObject(placemarksList);
        out.close();
    }

    public void readXML() throws IOException, ClassNotFoundException {
        XStream xstream = new XStream(new DomDriver());
        ObjectInputStream is = xstream.createObjectInputStream(new FileReader("placemarks.xml"));
        placemarksList = (ArrayList<Placemark>) is.readObject();
        is.close();
    }

    public void setWaypoint() {
        //now draws more than one rectangle
        pane.setOnMouseClicked(e-> {
            if (e.getButton().equals(MouseButton.PRIMARY)) {
                //mapImgView.toFront();
                double xCoord = e.getX();
                double yCoord = e.getY();
                //pane.toFront();
                Rectangle rectangleStart = new Rectangle();
                rectangleStart.setX(xCoord);
                rectangleStart.setY(yCoord);
                rectangleStart.setWidth(5);
                rectangleStart.setHeight(5);
                rectangleStart.setFill(Color.BLUE);
                pane.getChildren().add(rectangleStart);
                rectangleStart.relocate(xCoord, yCoord);
                System.out.println("xCoord: " + xCoord + ", yCoord: " + yCoord);
            }
            else if (e.getButton().equals(MouseButton.SECONDARY)) {
                //mapImgView.toFront();
                double xCoord = e.getX();
                double yCoord = e.getY();
                //pane.toFront();
                Rectangle rectangleEnd = new Rectangle();
                rectangleEnd.setX(xCoord);
                rectangleEnd.setY(yCoord);
                rectangleEnd.setWidth(5);
                rectangleEnd.setHeight(5);
                rectangleEnd.setFill(Color.RED);
                pane.getChildren().add(rectangleEnd);
                rectangleEnd.relocate(xCoord, yCoord);
                System.out.println("xCoord: " + xCoord + ", yCoord: " + yCoord);
            }
        });
    }
    
    public void setUpMap() {
        for (Placemark circlePlacemark : placemarksList) {
            Vec2d realCoords = new Vec2d(41.9028, 12.4964);
            //mapImgView.toFront();
            Circle circle = new Circle();
            Double xValue = Double.parseDouble(circlePlacemark.getxCoordinates());
            Double yValue = Double.parseDouble(circlePlacemark.getyCoordinates());
            circle.setCenterX(xValue);
            circle.setCenterY(yValue);
            circle.setRadius(5);
            circle.setFill(Color.GREEN);
            pane.getChildren().addAll(circle);
            Label label = new Label();
            label.setText(circlePlacemark.getName());
            label.setLayoutX(circle.getCenterX());
            label.setLayoutY(circle.getCenterY());
            pane.getChildren().addAll(label);
        }
    }

    public void quit(ActionEvent actionEvent) {
        Platform.exit();
    }

    public void goToAbout(ActionEvent actionEvent) {
        //not yet implemented (no rush)
    }

    public void search(ActionEvent actionEvent) {
        searchPrintToInfoField();
        //.
        //System.out.println(graph.depthFirst(originTxtFld.getText(), destinationTxtFld.getText()));
        //System.out.println(graph.breadthFirst(originTxtFld.getText(), destinationTxtFld.getText()));
        //System.out.println(graph.printGraph());

        String input = "\r\n" + "Found the following route for" + " " + originTxtFld.getText() + " - " + destinationTxtFld.getText() + "\r\n";
        System.out.println(input);
        infoTxtBox.appendText(input);

        if (originTxtFld.getText().equals(a.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(a, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(b.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(b, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(c.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(c, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(d.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(d, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(e.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(e, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(f.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(f, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(g.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(g, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(h.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(h, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(i.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(i, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(j.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(j, null, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        if (algoComboBox.getValue().equals("BFS")) {
            BFS();
        } else if (algoComboBox.getValue().equals("Dijkstra")) {
            Dijkstra();
        } else if (avoidTckBox.isSelected()) {
            Avoids();
        }
    }

    public void searchPrintToInfoField() {
        infoTxtBox.setText("You have chosen the origin: " + originTxtFld.getText() + "\n" +
                "You have chosen the destination: " + destinationTxtFld.getText() + "\n" +
                "The chosen algorithm is: " + algoComboBox.getValue());
    }

    public void Avoids() {

        if (originTxtFld.getText().equals(a.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(a, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(b.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(b, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(c.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(c, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(d.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(d, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(e.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(e, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(f.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(f, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(g.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(g, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(h.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(h, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(i.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(i, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        } else if (originTxtFld.getText().equals(j.data)) {
            List<GraphNodeAL<?>> path = findPathDepthFirst(j, algoComboBox.getItems(), destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }
    }

    public void BFS() {
        String input = "\r\n" + "Found the following Breadth First route for" + " " + originTxtFld.getText() + " - " + destinationTxtFld.getText() + "\r\n";
        System.out.println(input);
        infoTxtBox.appendText(input);

        if (originTxtFld.getText().equals(a.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(a, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(b.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(b, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(c.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(c, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(d.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(d, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(e.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(e, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(f.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(f, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(g.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(g, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(h.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(h, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(i.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(i, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }

        else if (originTxtFld.getText().equals(j.data)) {
            List<GraphNodeAL<?>> path = findPathBreadthFirst(j, destinationTxtFld.getText());
            if (path != null) {
                for (GraphNodeAL<?> n : path) {
                    String output = "\r\n" + (String) n.data;
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            }
        }
    }

    public void Dijkstra() {
        String input = "\r\n" + "Found the following Dijkstra route for" + " " + originTxtFld.getText() + " - " + destinationTxtFld.getText() + "\r\n";
        System.out.println(input);
        infoTxtBox.appendText(input);


        if (originTxtFld.getText().equals(a.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Da, destinationTxtFld.getText());
                for (GraphNodeAL2<?> n : costedPath.pathList) {
                    String output = "\r\n" + (String) n.data + "\r\n";
                    System.out.println(output);
                    infoTxtBox.appendText(output);
                }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(b.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Db, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(c.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Dc, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(d.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Dd, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(e.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(De, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(f.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Df, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(g.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Dg, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(h.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Dh, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(i.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Di, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }

        else if (originTxtFld.getText().equals(j.data)) {
            GraphNodeAL2.CostedPath costedPath = findCheapestPathDijkstra(Dj, destinationTxtFld.getText());
            for (GraphNodeAL2<?> n : costedPath.pathList) {
                String output = "\r\n" + (String) n.data + "\r\n";
                System.out.println(output);
                infoTxtBox.appendText(output);
            }
            String output = "\r\n" + "Total cost is: " + costedPath.pathCost + "\r\n";
            System.out.println(output);
            infoTxtBox.appendText(output);
        }
    }


    public void BFS_Map() throws IOException {
        //https://stackoverflow.com/questions/56233780/convert-an-image-into-an-occupancy-grid/56234448
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        Mat image = Imgcodecs.imread("rome-map.jpg", Imgproc.COLOR_BGR2GRAY);
        Mat bwImage;
        bwImage = image;
        Imgproc.threshold(image, bwImage, 60, 255, Imgproc.THRESH_BINARY);
        Core.divide(bwImage, new Scalar(255.0), bwImage);
        FileWriter gridFile = new FileWriter("output.jpg");
        Imgcodecs.imwrite("output.jpg", bwImage);
    }

    public void binaryDataGrid() throws IOException {
        BufferedImage image = ImageIO.read(new File("rome-map-bw.jpg"));
        byte[][] pixels = new byte[image.getWidth()][];

        for (int x = 0; x < image.getWidth(); x++) {
            pixels[x] = new byte[image.getHeight()];

            for (int y = 0; y < image.getHeight(); y++) {
                pixels[x][y] = (byte) (image.getRGB(x, y) == 0xFFFFFFFF ? 0 : 1);
            }
        }
        System.out.println(pixels.toString());
    }

    //https://www.text-image.com/convert/pic2html.cgi

    /*
    public void binaryMap() {
        int[][] map = {
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
                {0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1},
        };

       Graphics g;

        g.translate(50, 50);

        //draw the map
        for (int row = 0; row < map.length; row++) {
            for (int col = 0; col < map[0].length; col++) {
                Color color;
                switch (map[row][col]) {
                    case 1:
                        color = Color.BLACK;
                        break;
                    default:
                        color = Color.WHITE;
                }
                g.setColor(color);
                g.fillRect(30 * col, 30 * row, 30, 30);
                g.setColor(Color.BLACK);
                g.drawRect(30 * col, 30 * row, 30, 30);
            }
        }
    }
     */

    public void addToDatabase (ActionEvent actionEvent) throws Exception {
        checkForErrors();
        Placemark placemark = new Placemark(typeComboBox.getValue(), nameTxtFld.getText(), descTxtFld.getText(), xTxtFld.getText(), yTxtFld.getText());
        //.
        graph.addVertex(nameTxtFld.getText());
        placemarksList.add(placemark);
        saveXML();
    }

    public void checkForErrors() {
        if (descTxtFld.getText().isEmpty()) {
            descTxtFld.setText("null");
        }
        if (xTxtFld.getText().isEmpty()) {
            xTxtFld.setText("-0.0");
        }
        if (yTxtFld.getText().isEmpty()) {
            yTxtFld.setText("-0.0");
        }
    }

    public void openGoogleMaps(ActionEvent actionEvent) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource("../FXML/webView.fxml")));
        Stage stage = new Stage();
        stage.setTitle("Google Maps - Rome");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

    public void secret(ActionEvent actionEvent) {
        //meme?
    }

    public void exit(ActionEvent actionEvent) {
        Platform.exit();
    }
}
